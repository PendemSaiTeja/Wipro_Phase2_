package com.example.entity;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Data

public class Faculty {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;

    @ManyToOne
    @JoinColumn(name = "department_id")
    private Department department;

    public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Department getDepartment() {
		return department;
	}

	public void setDepartment(Department department) {
		this.department = department;
	}

	private boolean isHOD;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public boolean isHOD() {
		return isHOD;
	}

	public void setHOD(boolean isHOD) {
		this.isHOD = isHOD;
	}
}